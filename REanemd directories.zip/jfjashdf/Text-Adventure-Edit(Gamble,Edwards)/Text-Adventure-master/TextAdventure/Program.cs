﻿// We use the System namespace for the Console and Convert classes.
using System;

// We use the System.IO namespace for the StreamReader class.
using System.IO;

// We use the System.Collections.Generic namespace for the List class.
using System.Collections.Generic;

// This namespace contains our game.
namespace TextAdventure
{
    // All our game code is in a single class.
    class Program
    {
        // Entry point to the program.
        static void Main(string[] args)
        {
            // Change the window title.
            Console.Title = "Text Adventure!";

            // Start at node 0000.txt.
            string node = "Nodes\\0000.txt";

            // Boolean switch used to exit the game.
            bool isRunning = true;

            // Run the game loop until the game ends.
            while (isRunning)
            {
                // Use the StreamReader to load the data for the current node.
                StreamReader sr = new StreamReader(node);

                // Holds the nodes linked to this node.
                List<string> nodes = new List<string>();

                // This loop pulls the data from the node file.
                while (!sr.EndOfStream)
                {
                    // Grab a line from the node file. Trim any whitespace.
                    string line = sr.ReadLine().Trim();

                    // If the line is --- that means we are done writing the
                    // description and now we can write the options.
                    if (line == "---")
                    {
                        // Read to the end of the node file.
                        while (!sr.EndOfStream)
                        {
                            // Grab the next line. Trim any whitespace.
                            line = sr.ReadLine().Trim();

                            // Split at the | to separate the option text and the
                            // associated node.
                            string[] parts = line.Split('|');

                            // Add the node to the nodes list.
                            nodes.Add(parts[1].Trim());

                            // Write the option to the console.
                            Console.WriteLine(parts[0]);
                        }
                    }
                    // Else we are still reading the description, so...
                    else
                    {
                        // ... write the description line to the console window.
                        Console.WriteLine(line);
                    }
                }

                // Close the StreamReader.
                sr.Close();

                // Write an extra line to space things out.
                Console.WriteLine();

                // If there are selectable nodes, then...
                if (nodes.Count > 0)
                {
                    // ... get the user's selection.
                    int n = Convert.ToInt32(Console.ReadLine());

                    // Clear the console window.
                    Console.Clear();

                    // Set the new node depending on the user input.
                    node = "Nodes\\" + nodes[n - 1];
                }
                // Else there are no selectable nodes, which means the
                // game is over, so...
                else
                {
                    // ... quit the game by toggling the isRunning boolean to false.
                    isRunning = false;
                }
            }

            // Hold the console window open until the user presses a key.
            Console.ReadKey();
        }
    }
}
